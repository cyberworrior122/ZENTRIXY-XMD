const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, jidNormalizedUser, DisconnectReason, generateWAMessageContent, proto } = require('@whiskeysockets/baileys')
const pino = require('pino')
const fs = require('fs')
const { rmSync } = require('fs')
const chalk = require('chalk')
const NodeCache = require('node-cache')
const readline = require('readline')

// Kuunganisha handleMessages kutoka main.js ili amri kama .menu zifanye kazi
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main')

const pairingCode = true
const useMobile = false
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

async function startZentrixyBotInc() {
    try {
        let { version, isLatest } = await fetchLatestBaileysVersion()
        const { state, saveCreds } = await useMultiFileAuthState(`./session`)
        const msgRetryCounterCache = new NodeCache()

        const ZentrixyBotInc = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: !pairingCode,
            browser: ["Ubuntu", "Chrome", "20.0.04"],
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
            },
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            getMessage: async (key) => {
                let jid = jidNormalizedUser(key.remoteJid)
                let msg = global.store && global.store.loadMessage ? await global.store.loadMessage(jid, key.id) : ""
                return msg?.message || ""
            },
            msgRetryCounterCache,
            defaultQueryTimeoutMs: 60000,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 10000,
        })

        ZentrixyBotInc.ev.on('creds.update', saveCreds)

        if (global.store) {
            global.store.bind(ZentrixyBotInc.ev)
        }

        ZentrixyBotInc.public = true

        // Kusikiliza na kushughulikia ujumbe wote unaoingia (amri za bot)
        ZentrixyBotInc.ev.on('messages.upsert', async chatUpdate => {
            try {
                await handleMessages(ZentrixyBotInc, chatUpdate, true);
            } catch (err) {
                console.error("Error in messages.upsert:", err);
            }
        });

        // Kusikiliza mabadiliko kwenye magroup (welcome, goodbye, promote n.k)
        ZentrixyBotInc.ev.on('group-participants.update', async (update) => {
            await handleGroupParticipantUpdate(ZentrixyBotInc, update);
        });

        // Kusikiliza status za WhatsApp
        ZentrixyBotInc.ev.on('messages.upsert', async (m) => {
            if (m.messages[0].key && m.messages[0].key.remoteJid === 'status@broadcast') {
                await handleStatus(ZentrixyBotInc, m);
            }
        });

        if (pairingCode && !ZentrixyBotInc.authState.creds.registered) {
            if (useMobile) throw new Error('Cannot use pairing code with mobile api')

            let phoneNumber
            if (!!global.phoneNumber) {
                phoneNumber = global.phoneNumber
            } else {
                phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Weka namba yako ya WhatsApp (Mfano: 255694187430): `)))
            }

            phoneNumber = phoneNumber.replace(/[^0-9]/g, '')

            const pn = require('awesome-phonenumber');
            if (!pn('+' + phoneNumber).isValid()) {
                console.log(chalk.red('Namba ya simu si sahihi. Tafadhali weka namba kamili ya kimataifa bila + wala nafasi.'));
                process.exit(1);
            }

            setTimeout(async () => {
                try {
                    let code = await ZentrixyBotInc.requestPairingCode(phoneNumber)
                    code = code?.match(/.{1,4}/g)?.join("-") || code
                    console.log(chalk.black(chalk.bgGreen(` Your Pairing Code : `)), chalk.black(chalk.white(code)))
                    console.log(chalk.yellow(`\nWeka namba hii kwenye WhatsApp yako:\n1. Fungua WhatsApp\n2. Nenda Settings > Linked Devices\n3. Gusa "Link a Device"\n4. Chagua "Link with phone number instead" kisha uweke hizi namba`))
                } catch (error) {
                    console.error('Hitilafu katika kuomba pairing code:', error)
                    console.log(chalk.red('Imeshindikana kupata pairing code. Hakiki namba yako kisha ujaribu tena.'))
                }
            }, 3000)
        }

        ZentrixyBotInc.ev.on('connection.update', async (s) => {
            const { connection, lastDisconnect, qr } = s
            
            if (connection === 'connecting') {
                console.log(chalk.yellow('🔄 Inaunganisha na WhatsApp...'))
            }
            
            if (connection == "open") {
                console.log(chalk.magenta(` `))
                console.log(chalk.yellow(`Imeshikamana na => ${JSON.stringify(ZentrixyBotInc.user, null, 2)}`))

                // Hapa ndipo ujumbe unatumwa moja kwa moja kwenye inbox ya bot ikisha-connect
                const botJid = ZentrixyBotInc.user && ZentrixyBotInc.user.id ? ZentrixyBotInc.user.id.split(':')[0] + '@s.whatsapp.net' : '';

                if (botJid) {
                    setTimeout(async () => {
                        await ZentrixyBotInc.sendMessage(botJid, { 
                            text: '⚡ *ZENTRIXY XMD IS ACTIVE!*' 
                        });
                    }, 3000);
                }
            }
            
            if (connection === 'close') {
                const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut
                const statusCode = lastDisconnect?.error?.output?.statusCode
                
                console.log(chalk.red(`Muunganisho umefungwa kwa sababu ya ${lastDisconnect?.error}, inaunganisha tena ${shouldReconnect}`))
                
                if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
                    try {
                        rmSync('./session', { recursive: true, force: true })
                        console.log(chalk.yellow('Session imefutwa. Tafadhali unanisha upya.'))
                    } catch (error) {
                        console.error('Hitilafu katika kufuta session:', error)
                    }
                }
                
                if (shouldReconnect) {
                    console.log(chalk.yellow('Inaunganisha tena...'))
                    await delay(5000)
                    startZentrixyBotInc()
                }
            }
        })

        return ZentrixyBotInc
    } catch (error) {
        console.error('Hitilafu kwenye startZentrixyBotInc:', error)
        await delay(5000)
        startZentrixyBotInc()
    }
}

startZentrixyBotInc().catch(error => {
    console.error('Hitilafu kubwa:', error)
    process.exit(1)
})

process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err)
})

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err)
})

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Sasisho ${__filename}`))
    delete require.cache[file]
    require(file)
})