const fs = require('fs');
const path = require('path');

const ANTICALL_PATH = path.join(__dirname, '../data/anticall.json');

function readState() {
    try {
        if (!fs.existsSync(ANTICALL_PATH)) {
            return { enabled: false };
        }
        const raw = fs.readFileSync(ANTICALL_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');
        return { enabled: !!data.enabled };
    } catch (err) {
        console.error('Error reading anticall state:', err);
        return { enabled: false };
    }
}

function writeState(enabled) {
    try {
        const dir = path.dirname(ANTICALL_PATH);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(ANTICALL_PATH, JSON.stringify({ enabled: !!enabled }, null, 2), 'utf8');
        return true;
    } catch (err) {
        console.error('Error writing anticall state:', err);
        return false;
    }
}

async function anticallCommand(sock, chatId, message, args) {
    try {
        // Hakikisha ni mmiliki (owner) pekee anayeweza kutumia amri hii kama inahitajika
        // Unaweza kurekebisha kulingana na muundo wako wa udhibiti wa owner
        const senderId = message.key.participant || message.key.remoteJid;
        const isOwner = message.key.fromMe || (global.owner && global.owner.some(num => senderId.includes(num)));

        const state = readState();
        const sub = (args || '').trim().toLowerCase();

        if (!sub || (sub !== 'on' && sub !== 'off' && sub !== 'status')) {
            await sock.sendMessage(chatId, { 
                text: '🛡️ *ZENTRIXY XMD - ANTICALL*\n\n• `.anticall on` - Washa kuzuia simu zinazoingia moja kwa moja\n• `.anticall off` - Zima anticall\n• `.anticall status` - Angalia hali ya sasa' 
            }, { quoted: message });
            return;
        }

        if (sub === 'status') {
            await sock.sendMessage(chatId, { 
                text: `🛡️ Anticall kwa sasa iko: *${state.enabled ? 'IMEWASHWA (ON)' : 'IMEZIMWA (OFF)'}*.` 
            }, { quoted: message });
            return;
        }

        // Zuia wasio wenyewe kubadilisha setting hii kama unataka iwe ya owner pekee
        if (!isOwner) {
            await sock.sendMessage(chatId, { text: '❌ Samahani, ni mmiliki (owner) wa bot pekee anayeweza kubadilisha mpangilio huu!' }, { quoted: message });
            return;
        }

        const enable = sub === 'on';
        const success = writeState(enable);

        if (success) {
            await sock.sendMessage(chatId, { 
                text: `✅ Anticall imebadilishwa mafanikio. Sasa iko: *${enable ? 'IMEWASHWA (ENABLED)' : 'IMEZIMWA (DISABLED)'}*.` 
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { 
                text: '❌ Imeshindikana kuhifadhi mpangilio wa anticall kwenye mfumo.' 
            }, { quoted: message });
        }
    } catch (error) {
        console.error('Error in anticallCommand:', error);
        await sock.sendMessage(chatId, { text: '❌ Kosa limetokea wakati wa kuchakata amri ya anticall.' }, { quoted: message });
    }
}

module.exports = { anticallCommand, readState };


