const axios = require('axios');
const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, text, command }) => {
    try {
        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya Facebook.*\n\n" +
                "🇬🇧 *Please provide a valid Facebook video URL.*\n\n" +
                "*Mfano / Example:* `.fb https://www.facebook.com/...`"
            );
        }

        const url = urlMatch[0];

        // Validate Facebook URL
        if (!url.includes('facebook.com') && !url.includes('fb.watch')) {
            return m.reply("❌ Hii siyo link ya Facebook!\n🇬🇧 That is not a valid Facebook link.");
        }

        await m.reply("🔄 *Inachakata video ya Facebook, tafadhali subiri...*\n🇬🇧 *Processing Facebook video, please wait...*");

        // Resolve share/short URLs to their final destination first
        let resolvedUrl = url;
        try {
            const res = await axios.get(url, { timeout: 20000, maxRedirects: 10, headers: { 'User-Agent': 'Mozilla/5.0' } });
            const possible = res?.request?.res?.responseUrl;
            if (possible && typeof possible === 'string') {
                resolvedUrl = possible;
            }
        } catch {
            // Tumia original url kama ikishindikana
        }

        // Use Hanggts API
        const apiUrl = `https://api.hanggts.xyz/download/facebook?url=${encodeURIComponent(resolvedUrl)}`;
        const response = await axios.get(apiUrl, {
            timeout: 20000,
            headers: {
                'accept': '*/*',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            maxRedirects: 5,
            validateStatus: s => s >= 200 && s < 500
        });

        const data = response?.data;
        let fbvid = null;
        let title = "Facebook Video";

        if (data) {
            if (data.result) {
                if (data.result.media) {
                    fbvid = data.result.media.video_hd || data.result.media.video_sd;
                    title = data.result.info?.title || data.result.title || "Facebook Video";
                } else if (typeof data.result === 'object' && data.result.url) {
                    fbvid = data.result.url;
                    title = data.result.title || data.result.caption || "Facebook Video";
                } else if (typeof data.result === 'string' && data.result.startsWith('http')) {
                    fbvid = data.result;
                } else if (data.result.download) {
                    fbvid = data.result.download;
                } else if (data.result.video) {
                    fbvid = data.result.video;
                }
            }
            
            if (!fbvid && data.data) {
                if (typeof data.data === 'object' && data.data.url) {
                    fbvid = data.data.url;
                    title = data.data.title || data.data.caption || "Facebook Video";
                } else if (typeof data.data === 'string' && data.data.startsWith('http')) {
                    fbvid = data.data;
                } else if (data.data.download) {
                    fbvid = data.data.download;
                } else if (data.data.video) {
                    fbvid = data.data.video;
                }
            }
            
            if (!fbvid && data.url) {
                fbvid = data.url;
                title = data.title || data.caption || "Facebook Video";
            }
        }

        if (!fbvid) {
            return m.reply(
                "❌ *Imeshindikana kupata link ya video ya Facebook.*\n" +
                "Huenda video ni ya faragha (private) au imefutwa.\n\n" +
                "🇬🇧 *Failed to get video URL from Facebook. Video might be private or deleted.*"
            );
        }

        const captionText = `📥 *FACEBOOK VIDEO SUCCESSFUL*\n\n` +
                            `📌 *Jina / Title:* ${title}\n\n` +
                            `_Swahili & English: Imepakuliwa kupitia bot yako (GODS ZEAL XMD)._`;

        // Jaribu kutuma kupitia URL moja kwa moja
        try {
            await conn.sendMessage(m.chat, {
                video: { url: fbvid },
                mimetype: "video/mp4",
                caption: captionText
            }, { quoted: m });
            return;
        } catch (urlError) {
            console.error(`URL method failed, trying buffer: ${urlError.message}`);

            // Njia mbadala ya Buffer / Temp file kama URL ikigoma
            const tmpDir = path.join(process.cwd(), 'tmp');
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }

            const tempFile = path.join(tmpDir, `fb_${Date.now()}.mp4`);
            const videoResponse = await axios({
                method: 'GET',
                url: fbvid,
                responseType: 'stream',
                timeout: 60000
            });

            const writer = fs.createWriteStream(tempFile);
            videoResponse.data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            await conn.sendMessage(m.chat, {
                video: { url: tempFile },
                mimetype: "video/mp4",
                caption: captionText
            }, { quoted: m });

            // Safisha faili la muda
            try {
                if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            } catch (err) {
                console.error('Cleanup error:', err);
            }
        }

    } catch (error) {
        console.error('Error in Facebook command:', error);
        m.reply("❌ Kosa limetokea wakati wa kuchakata video hii. Jaribu tena baadae.\n🇬🇧 An error occurred while processing this video. Try again later.");
    }
};

// Usajili wa Command kwenye Menu List
handler.help = ['facebook', 'fb'];
handler.tags = ['media'];
handler.command = /^(facebook|fb)$/i;

module.exports = handler;
