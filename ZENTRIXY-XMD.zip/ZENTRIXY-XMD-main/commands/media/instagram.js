const { igdl } = require("ruhend-scraper");

// Store processed message IDs to prevent duplicates
const processedMessages = new Set();

function extractUniqueMedia(mediaData) {
    const uniqueMedia = [];
    const seenUrls = new Set();
    
    for (const media of mediaData) {
        if (!media.url) continue;
        if (!seenUrls.has(media.url)) {
            seenUrls.add(media.url);
            uniqueMedia.push(media);
        }
    }
    return uniqueMedia;
}

let handler = async (m, { conn, text, command }) => {
    try {
        // Zuia kurudia ujumbe ule ule (duplicate handling)
        if (processedMessages.has(m.key.id)) {
            return;
        }
        
        processedMessages.add(m.key.id);
        setTimeout(() => {
            processedMessages.delete(m.key.id);
        }, 5 * 60 * 1000);

        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya Instagram.*\n\n" +
                "🇬🇧 *Please provide a valid Instagram post, reel, or video link.*\n\n" +
                "*Mfano / Example:* `.insta https://www.instagram.com/p/...`"
            );
        }

        const targetUrl = urlMatch[0];

        // Angalia kama ni link ya Instagram
        const instagramPatterns = [
            /https?:\/\/(?:www\.)?instagram\.com\//,
            /https?:\/\/(?:www\.)?instagr\.am\//,
            /https?:\/\/(?:www\.)?instagram\.com\/p\//,
            /https?:\/\/(?:www\.)?instagram\.com\/reel\//,
            /https?:\/\/(?:www\.)?instagram\.com\/tv\//
        ];

        const isValidUrl = instagramPatterns.some(pattern => pattern.test(targetUrl));
        
        if (!isValidUrl) {
            return m.reply(
                "❌ *Hii siyo link halisi ya Instagram.*\n\n" +
                "🇬🇧 *That is not a valid Instagram link.*"
            );
        }

        await m.reply("🔄 *Inachakata faili la Instagram, tafadhali subiri...*\n🇬🇧 *Processing Instagram media, please wait...*");

        const downloadData = await igdl(targetUrl);
        
        if (!downloadData || !downloadData.data || downloadData.data.length === 0) {
            return m.reply(
                "❌ *Imeshindikana kupata data kutoka kwenye link hii. Huenda chapisho ni la faragha (private).* \n\n" +
                "🇬🇧 *No media found. The post might be private or the link is invalid.*"
            );
        }

        const mediaData = downloadData.data;
        const uniqueMedia = extractUniqueMedia(mediaData);
        const mediaToDownload = uniqueMedia.slice(0, 10); // Kikomo cha faili 10 kwa mara moja ili kuzuia spam
        
        if (mediaToDownload.length === 0) {
            return m.reply("❌ Hakuna faili sahihi la kupakuliwa.\n🇬🇧 No valid media found to download.");
        }

        for (let i = 0; i < mediaToDownload.length; i++) {
            try {
                const media = mediaToDownload[i];
                const mediaUrl = media.url;

                const isVideo = /\.(mp4|mov|avi|mkv|webm)$/i.test(mediaUrl) || 
                              media.type === 'video' || 
                              targetUrl.includes('/reel/') || 
                              targetUrl.includes('/tv/');

                const captionText = `📥 *INSTAGRAM DOWNLOAD SUCCESSFUL*\n\n_Swahili & English: Imepakuliwa kupitia bot yako (GODS ZEAL XMD)._`;

                if (isVideo) {
                    await conn.sendMessage(m.chat, {
                        video: { url: mediaUrl },
                        mimetype: "video/mp4",
                        caption: captionText
                    }, { quoted: m });
                } else {
                    await conn.sendMessage(m.chat, {
                        image: { url: mediaUrl },
                        caption: captionText
                    }, { quoted: m });
                }
                
                // Kuweka sekunde 1 ya kusubiri kati ya faili na faili (rate limit protection)
                if (i < mediaToDownload.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
                
            } catch (mediaError) {
                console.error(`Error downloading media ${i + 1}:`, mediaError);
            }
        }

    } catch (error) {
        console.error('Error in Instagram command:', error);
        m.reply("❌ Kosa limetokea wakati wa kuchakata ombi la Instagram. Jaribu tena.\n🇬🇧 An error occurred while processing the Instagram request. Please try again.");
    }
};

// Usajili wa Commands kwenye Menu List
handler.help = ['instagram', 'ig', 'insta'];
handler.tags = ['media'];
handler.command = /^(instagram|ig|insta)$/i;

module.exports = handler;
