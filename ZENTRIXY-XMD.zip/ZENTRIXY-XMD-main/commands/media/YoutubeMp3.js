const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
    try {
        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya YouTube ili kuitoa sauti (MP3).*\n\n" +
                "🇬🇧 *Please provide a valid YouTube link to get audio (MP3).*\n\n" +
                "*Mfano / Example:* `.youtubemp3 https://youtu.be/...`"
            );
        }

        const targetUrl = urlMatch[0];
        const isYouTube = targetUrl.includes('youtube.com') || targetUrl.includes('youtu.be');

        if (!isYouTube) {
            return m.reply("❌ Hii siyo link ya YouTube!\n🇬🇧 This is not a YouTube link!");
        }

        await m.reply("🔄 *Inabadilisha YouTube kuwa Audio (MP3), tafadhali subiri...*\n🇬🇧 *Converting YouTube to Audio (MP3), please wait...*");

        const ytAudioRes = await axios.get(`https://api.siputzx.my.id/api/d/ytmp3?url=${encodeURIComponent(targetUrl)}`);
        const mediaDownloadUrl = ytAudioRes?.data?.data?.dl;
        const mediaTitle = ytAudioRes?.data?.data?.title || 'YouTube Audio';

        if (!mediaDownloadUrl) {
            throw new Error('Imeshindikana kupata link ya sauti.');
        }

        const mediaBufferRes = await axios.get(mediaDownloadUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        const buffer = Buffer.from(mediaBufferRes.data);
        const cleanTitle = mediaTitle.replace(/[^\w\s-]/g, '').trim();
        const captionText = `🎵 *YOUTUBE AUDIO (MP3) SUCCESSFUL*\n📌 *Title:* ${mediaTitle}\n\n_Imepakuliwa kupitia bot yako._`;

        await conn.sendMessage(m.chat, {
            audio: buffer,
            mimetype: 'audio/mpeg',
            fileName: `${cleanTitle}.mp3`,
            ptt: false,
            caption: captionText
        }, { quoted: m });

    } catch (error) {
        console.error('YoutubeMp3 error:', error);
        m.reply("❌ Imeshindikana kugeuza link hii kuwa audio. Jaribu tena.\n🇬🇧 Failed to convert link to audio. Try again.");
    }
};

handler.help = ['youtubemp3', 'ytmp3'];
handler.tags = ['media'];
handler.command = /^(youtubemp3|ytmp3)$/i;

module.exports = handler;
