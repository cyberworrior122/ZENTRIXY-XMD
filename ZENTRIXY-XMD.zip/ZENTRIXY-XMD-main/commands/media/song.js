const yts = require('yt-search');

let handler = async (m, { conn, text, command }) => {
    try {
        const searchQuery = text ? text : (m.text ? m.text.split(' ').slice(1).join(' ').trim() : '');
        
        if (!searchQuery) {
            return m.reply(
                "❌ *Tafadhali weka jina la wimbo unaotaka kutafuta.*\n\n" +
                "🇬🇧 *Please provide a song name to search.*\n\n" +
                "*Mfano / Example:* `.song Diamond Platnumz`"
            );
        }

        await m.reply("🔄 *Inatafuta wimbo, tafadhali subiri...*\n🇬🇧 *Searching for song, please wait...*");

        // Tafuta wimbo kupitia yt-search
        const search = await yts(searchQuery);
        const videos = search.videos;
        
        if (!videos || videos.length === 0) {
            return m.reply(
                "❌ *Samahani, hatujapata wimbo wowote kwa jina hilo!*\n\n" +
                "🇬🇧 *Sorry, no song found with that name!*"
            );
        }

        const video = videos[0];

        // Ujumbe wenye maelezo na link ya wimbo kwa lugha mbili
        const caption = `🎵 *YOUTUBE SONG SEARCH / UMEPATIKANA* 🎵\n\n` +
                        `📌 *Kichwa / Title:* ${video.title}\n` +
                        `⏱️ *Muda / Duration:* ${video.timestamp || 'Unknown'}\n` +
                        `👀 *Watazamaji / Views:* ${video.views ? video.views.toLocaleString() : 'N/A'}\n` +
                        `🔗 *Link:* ${video.url}\n\n` +
                        `_Swahili: Taarifa na link ya wimbo kupitia bot yako._\n` +
                        `_English: Song info and link retrieved via your bot._`;

        await conn.sendMessage(m.chat, {
            image: { url: video.thumbnail || 'https://i.imgur.com/Jo9X3Ww.jpeg' },
            caption: caption
        }, { quoted: m });

    } catch (error) {
        console.error('Song command error:', error);
        m.reply(
            "❌ *Imeshindikana kutafuta wimbo kwa sasa. Jaribu tena baadae.*\n\n" +
            "🇬🇧 *Failed to search for the song. Please try again later.*"
        );
    }
};

// Usajili wa Command kwenye Menu List
handler.help = ['song', 'searchsong'];
handler.tags = ['media'];
handler.command = /^(song|searchsong)$/i;

module.exports = handler;
