const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
    try {
        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya TikTok ili kutoa sauti (MP3).*\n\n" +
                "🇬🇧 *Please provide a valid TikTok link to extract audio (MP3).*\n\n" +
                "*Mfano / Example:* `.tiktokmp3 https://vt.tiktok.com/...`"
            );
        }

        const targetUrl = urlMatch[0];
        const isTikTok = targetUrl.includes('tiktok.com') || targetUrl.includes('vt.tiktok.com');

        if (!isTikTok) {
            return m.reply("❌ Hii siyo link ya TikTok!\n🇬🇧 This is not a TikTok link!");
        }

        await m.reply("🔄 *Inatoa sauti (Audio) kutoka TikTok, tafadhali subiri...*\n🇬🇧 *Extracting audio from TikTok, please wait...*");

        const tikRes = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(targetUrl)}`);
        const data = tikRes?.data?.data;

        if (!data) {
            throw new Error('Imeshindikana kupata data za TikTok audio.');
        }

        const mediaDownloadUrl = data.audio || data.music;
        const mediaTitle = data.title || 'TikTok Audio';
        const mediaAuthor = data.author?.nickname || 'TikTok User';

        if (!mediaDownloadUrl) {
            throw new Error('Sauti haipatikani kwenye link hii ya TikTok.');
        }

        const mediaBufferRes = await axios.get(mediaDownloadUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        const buffer = Buffer.from(mediaBufferRes.data);
        const cleanTitle = mediaTitle.replace(/[^\w\s-]/g, '').trim();
        const captionText = `🎶 *TIKTOK AUDIO (MP3) SUCCESSFUL*\n📌 *Title:* `${mediaTitle}\n👤 *Author:* ${mediaAuthor}\n\n_Imepakuliwa kupitia bot yako._`;

        await conn.sendMessage(m.chat, {
            audio: buffer,
            mimetype: 'audio/mpeg',
            fileName: `${cleanTitle}.mp3`,
            ptt: false,
            caption: captionText
        }, { quoted: m });

    } catch (error) {
        console.error('TiktokMp3 error:', error);
        m.reply("❌ Imeshindikana kupakua sauti ya TikTok hii. Jaribu tena.\n🇬🇧 Failed to download TikTok audio. Try again.");
    }
};

handler.help = ['tiktokmp3', 'ttmp3'];
handler.tags = ['media'];
handler.command = /^(tiktokmp3|ttmp3)$/i;

module.exports = handler;
