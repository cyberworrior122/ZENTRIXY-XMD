const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
    try {
        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya YouTube.*\n\n" +
                "🇬🇧 *Please provide a valid YouTube link.*\n\n" +
                "*Mfano / Example:* `.video https://youtu.be/...`"
            );
        }

        const targetUrl = urlMatch[0];
        const isYouTube = targetUrl.includes('youtube.com') || targetUrl.includes('youtu.be');

        if (!isYouTube) {
            return m.reply("❌ Hii siyo link ya YouTube! Tumia faili husika kwa ajili ya TikTok.\n🇬🇧 This is not a YouTube link! Use the respective TikTok file.");
        }

        await m.reply("🔄 *Inachakata video yako ya YouTube, tafadhali subiri...*\n🇬🇧 *Processing your YouTube video, please wait...*");

        const ytVideoRes = await axios.get(`https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(targetUrl)}`);
        const mediaDownloadUrl = ytVideoRes?.data?.data?.dl;
        const mediaTitle = ytVideoRes?.data?.data?.title || 'YouTube Video';

        if (!mediaDownloadUrl) {
            throw new Error('Imeshindikana kupata link ya video.');
        }

        const mediaBufferRes = await axios.get(mediaDownloadUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        const buffer = Buffer.from(mediaBufferRes.data);
        const captionText = `🎥 *YOUTUBE VIDEO SUCCESSFUL*\n📌 *Title:* ${mediaTitle}\n\n_Imepakuliwa kupitia bot yako._`;

        await conn.sendMessage(m.chat, {
            video: buffer,
            mimetype: 'video/mp4',
            caption: captionText
        }, { quoted: m });

    } catch (error) {
        console.error('Video error:', error);
        m.reply("❌ Imeshindikana kupakua video hii. Jaribu tena.\n🇬🇧 Failed to download this video. Try again.");
    }
};

handler.help = ['video'];
handler.tags = ['media'];
handler.command = /^(video)$/i;

module.exports = handler;
