
const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
    try {
        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya TikTok.*\n\n" +
                "🇬🇧 *Please provide a valid TikTok link.*\n\n" +
                "*Mfano / Example:* `.tiktok https://vt.tiktok.com/...`"
            );
        }

        const targetUrl = urlMatch[0];
        const isTikTok = targetUrl.includes('tiktok.com') || targetUrl.includes('vt.tiktok.com');

        if (!isTikTok) {
            return m.reply("❌ Hii siyo link ya TikTok!\n🇬🇧 This is not a TikTok link!");
        }

        await m.reply("🔄 *Inachakata video ya TikTok, tafadhali subiri...*\n🇬🇧 *Processing TikTok video, please wait...*");

        const tikRes = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(targetUrl)}`);
        const data = tikRes?.data?.data;

        if (!data) {
            throw new Error('Imeshindikana kupata data za TikTok.');
        }

        const mediaDownloadUrl = data.nowm || data.hd || data.video;
        const mediaTitle = data.title || 'TikTok Video';
        const mediaAuthor = data.author?.nickname || 'TikTok User';

        const mediaBufferRes = await axios.get(mediaDownloadUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        const buffer = Buffer.from(mediaBufferRes.data);
        const captionText = `📱 *TIKTOK VIDEO SUCCESSFUL*\n📌 *Title:* ${mediaTitle}\n👤 *Author:* ${mediaAuthor}\n\n_Imepakuliwa kupitia bot yako._`;

        await conn.sendMessage(m.chat, {
            video: buffer,
            mimetype: 'video/mp4',
            caption: captionText
        }, { quoted: m });

    } catch (error) {
        console.error('TikTok error:', error);
        m.reply("❌ Imeshindikana kupakua video hii ya TikTok.\n🇬🇧 Failed to download this TikTok video.");
    }
};

handler.help = ['tiktok'];
handler.tags = ['media'];
handler.command = /^(tiktok)$/i;

module.exports = handler;