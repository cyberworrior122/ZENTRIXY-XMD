const yts = require('yt-search');
const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
    try {
        const searchQuery = text ? text : (m.text ? m.text.split(' ').slice(1).join(' ').trim() : '');
        
        if (!searchQuery) {
            return m.reply(
                "❌ *Tafadhali weka jina la wimbo unaotaka kutafuta.*\n\n" +
                "🇬🇧 *Please provide a song name or search query.*\n\n" +
                "*Mfano / Example:* `.play Diamond Platnumz`"
            );
        }

        await m.reply("🔄 *Inatafuta wimbo wako, tafadhali subiri...*\n🇬🇧 *Searching for your song, please wait...*");

        // Search for the song
        const search = await yts(searchQuery);
        const videos = search.videos;
        
        if (!videos || videos.length === 0) {
            return m.reply(
                "❌ *Samahani, hatujapata wimbo wowote kwa jina hilo!*\n\n" +
                "🇬🇧 *Sorry, no song found with that name!*"
            );
        }

        const video = videos[0];
        const urlYt = video.url;
        let audioUrl = null;
        let title = video.title || 'Audio Song';

        // Tuma ujumbe wa picha na taarifa za wimbo kabla ya kuanza kupakua
        const captionText = `🎵 *PLAY SONG / UMEPATA WIMBO* 🎵\n\n` +
                            `📌 *Jina / Title:* ${title}\n` +
                            `⏱️ *Muda / Duration:* ${video.timestamp || 'Unknown'}\n` +
                            `👤 *Mtayarishaji / Author:* ${video.author?.name || 'Unknown'}\n\n` +
                            `_Swahili: Inapakua faili la sauti, tafadhali subiri..._\n` +
                            `_English: Downloading audio file, please wait..._`;

        await conn.sendMessage(m.chat, {
            image: { url: video.thumbnail || 'https://i.imgur.com/Jo9X3Ww.jpeg' },
            caption: captionText
        }, { quoted: m });

        // Mfumo wa API za akiba (Fallback Chain) ili isikwame
        const apis = [
            async () => {
                const res = await axios.post('https://co.wuk.sh/api/json', {
                    url: urlYt,
                    isAudioOnly: true
                }, {
                    headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
                    timeout: 30000
                });
                if (res?.data?.url) return res.data.url;
                throw new Error('Cobalt failed');
            },
            async () => {
                const res = await axios.get(`https://api.vrt.my.id/api/downloader/ytmp3?url=${encodeURIComponent(urlYt)}`, { timeout: 30000 });
                return res?.data?.download || res?.data?.dl || res?.data?.result;
            },
            async () => {
                const res = await axios.get(`https://api.siputzx.my.id/api/d/ytmp3?url=${encodeURIComponent(urlYt)}`, { timeout: 30000 });
                return res?.data?.data?.dl;
            }
        ];

        for (const api of apis) {
            try {
                const dl = await api();
                if (dl) {
                    audioUrl = dl;
                    break;
                }
            } catch (e) {
                continue;
            }
        }

        if (!audioUrl) {
            return m.reply(
                "❌ *Imeshindikana kupakua wimbo huu kupitia vyanzo vyote. Jaribu wimbo mwingine.*\n\n" +
                "🇬🇧 *Failed to download this song through all sources. Try another song.*"
            );
        }

        const cleanTitle = title.replace(/[^\w\s-]/g, '').trim();

        // Send the audio file
        await conn.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: "audio/mpeg",
            fileName: `${cleanTitle || 'song'}.mp3`,
            ptt: false
        }, { quoted: m });

    } catch (error) {
        console.error('Error in play command:', error);
        m.reply(
            "❌ *Kimetokea kitu kibaya wakati wa kupakua wimbo. Tafadhali jaribu tena baadaye.*\n\n" +
            "🇬🇧 *An error occurred while downloading the song. Please try again later.*"
        );
    }
};

// Usajili wa Command kwenye Menu List
handler.help = ['play', 'song'];
handler.tags = ['media'];
handler.command = /^(play|song)$/i;

module.exports = handler;

/*Powered by ZENTRIXY XMD*/