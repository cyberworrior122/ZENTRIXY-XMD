const { igdl } = require("ruhend-scraper");
const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
    try {
        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya Instagram ili kutoa sauti (MP3).*\n\n" +
                "🇬🇧 *Please provide a valid Instagram link to extract audio (MP3).*\n\n" +
                "*Mfano / Example:* `.instagrammp3 https://www.instagram.com/reel/...`"
            );
        }

        const targetUrl = urlMatch[0];

        if (!targetUrl.includes('instagram.com') && !targetUrl.includes('instagr.am')) {
            return m.reply("❌ Hii siyo link halisi ya Instagram!\n🇬🇧 That is not a valid Instagram link.");
        }

        await m.reply("🔄 *Inachakata na kutoa sauti kutoka Instagram, tafadhali subiri...*\n🇬🇧 *Extracting audio from Instagram, please wait...*");

        const downloadData = await igdl(targetUrl);
        
        if (!downloadData || !downloadData.data || downloadData.data.length === 0) {
            return m.reply("❌ Imeshindikana kupata media kutoka Instagram.\n🇬🇧 No media found from Instagram link.");
        }

        // Tafuta link yenye video au inayoweza kutoa audio
        const mediaItem = downloadData.data.find(item => item.url) || downloadData.data[0];
        const mediaUrl = mediaItem?.url;

        if (!mediaUrl) {
            throw new Error('Link ya sauti haipatikani.');
        }

        // Pakua faili ili litumwe kama audio
        const mediaBufferRes = await axios.get(mediaUrl, {
            responseType: 'arraybuffer',
            timeout: 60000
        });

        const buffer = Buffer.from(mediaBufferRes.data);
        const captionText = `🎶 *INSTAGRAM AUDIO (MP3) SUCCESSFUL*\n\n` +
                            `_Swahili & English: Imepakuliwa na kugeuzwa kuwa audio kupitia bot yako (GODS ZEAL XMD)._`;

        await conn.sendMessage(m.chat, {
            audio: buffer,
            mimetype: 'audio/mpeg',
            fileName: `instagram_audio.mp3`,
            ptt: false,
            caption: captionText
        }, { quoted: m });

    } catch (error) {
        console.error('InstagramMp3 error:', error);
        m.reply("❌ Imeshindikana kuchakata sauti ya Instagram. Jaribu tena.\n🇬🇧 Failed to process Instagram audio. Try again.");
    }
};

handler.help = ['instagrammp3', 'igmp3', 'instamp3'];
handler.tags = ['media'];
handler.command = /^(instagrammp3|igmp3|instamp3)$/i;

module.exports = handler;
