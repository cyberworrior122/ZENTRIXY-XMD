const axios = require('axios');

let handler = async (m, { conn, text, command }) => {
    try {
        const urlMatch = text ? text.match(/(https?:\/\/[^\s]+)/g) : (m.text ? m.text.match(/(https?:\/\/[^\s]+)/g) : null);
        
        if (!urlMatch) {
            return m.reply(
                "❌ *Tafadhali weka link sahihi ya Facebook ili kutoa sauti (MP3).*\n\n" +
                "🇬🇧 *Please provide a valid Facebook video URL to extract audio (MP3).*\n\n" +
                "*Mfano / Example:* `.facebookmp3 https://www.facebook.com/...`"
            );
        }

        const targetUrl = urlMatch[0];

        if (!targetUrl.includes('facebook.com') && !targetUrl.includes('fb.watch')) {
            return m.reply("❌ Hii siyo link halisi ya Facebook!\n🇬🇧 That is not a valid Facebook link.");
        }

        await m.reply("🔄 *Inachakata na kugeuza Facebook kuwa Audio (MP3), tafadhali subiri...*\n🇬🇧 *Converting Facebook to Audio (MP3), please wait...*");

        // Tunatumia API ya kuchomoa data ya video ya Facebook kwanza
        const apiUrl = `https://api.hanggts.xyz/download/facebook?url=${encodeURIComponent(targetUrl)}`;
        const response = await axios.get(apiUrl, {
            timeout: 20000,
            headers: { 'accept': '*/*', 'User-Agent': 'Mozilla/5.0' }
        });

        const data = response?.data;
        let fbvid = null;
        let title = "Facebook Audio";

        if (data) {
            if (data.result?.media) {
                fbvid = data.result.media.video_hd || data.result.media.video_sd;
                title = data.result.info?.title || data.result.title || "Facebook Audio";
            } else if (data.result?.url) {
                fbvid = data.result.url;
                title = data.result.title || "Facebook Audio";
            } else if (data.data?.url) {
                fbvid = data.data.url;
                title = data.data.title || "Facebook Audio";
            } else if (typeof data.result === 'string') {
                fbvid = data.result;
            }
        }

        if (!fbvid) {
            throw new Error('Imeshindikana kupata link ya media kutoka Facebook.');
        }

        // Pakua faili kama buffer ya audio
        const mediaBufferRes = await axios.get(fbvid, {
            responseType: 'arraybuffer',
            timeout: 60000
        });

        const buffer = Buffer.from(mediaBufferRes.data);
        const cleanTitle = title.replace(/[^\w\s-]/g, '').trim();

        const captionText = `🎵 *FACEBOOK AUDIO (MP3) SUCCESSFUL*\n\n` +
                            `📌 *Jina / Title:* ${title}\n\n` +
                            `_Swahili & English: Imepakuliwa na kugeuzwa kuwa audio kupitia bot yako (GODS ZEAL XMD)._`;

        await conn.sendMessage(m.chat, {
            audio: buffer,
            mimetype: 'audio/mpeg',
            fileName: `${cleanTitle}.mp3`,
            ptt: false,
            caption: captionText
        }, { quoted: m });

    } catch (error) {
        console.error('FacebookMp3 error:', error);
        m.reply("❌ Imeshindikana kugeuza video hii ya Facebook kuwa audio. Jaribu tena.\n🇬🇧 Failed to convert Facebook video to audio. Try again.");
    }
};

handler.help = ['facebookmp3', 'fbmp3'];
handler.tags = ['media'];
handler.command = /^(facebookmp3|fbmp3)$/i;

module.exports = handler;
