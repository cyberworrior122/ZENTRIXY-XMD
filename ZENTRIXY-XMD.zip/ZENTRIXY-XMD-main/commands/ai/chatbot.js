const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Faili la kuhifadhi hali ya chatbot (kama imewashwa au imezimwa)
const CHATBOT_PATH = path.join(__dirname, '../data/chatbot.json');

function readChatbotState() {
    try {
        if (!fs.existsSync(CHATBOT_PATH)) return { enabled: false };
        const raw = fs.readFileSync(CHATBOT_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');
        return { enabled: !!data.enabled };
    } catch {
        return { enabled: false };
    }
}

function writeChatbotState(enabled) {
    try {
        const dir = path.dirname(CHATBOT_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(CHATBOT_PATH, JSON.stringify({ enabled: !!enabled }, null, 2), 'utf8');
    } catch {}
}

// Kitendakazi kikuu cha kusoma na kujibu ujumbe kupitia Gemini AI
async function handleAutoChatbot(sock, mek, m) {
    try {
        const state = readChatbotState();
        const body = m.body || m.text || '';
        const chatId = m.chat;
        const sender = m.sender;

        // Amri ya kuwasha au kuzima chatbot (.chatbot on / off)
        if (body.startsWith('.chatbot')) {
            const isOwner = mek.key.fromMe || (global.owner && global.owner.some(num => sender.includes(num)));
            if (!isOwner) {
                await sock.sendMessage(chatId, { 
                    text: '❌ *Swahili:* Samahani, ni mmiliki pekee anayeweza kuwasha au kuzima AI Chatbot!\n\n❌ *English:* Sorry, only the owner can enable or disable the AI Chatbot!' 
                }, { quoted: mek });
                return;
            }

            const args = body.slice(8).trim().toLowerCase();
            if (args === 'on') {
                writeChatbotState(true);
                await sock.sendMessage(chatId, { 
                    text: '🤖 *ZENTRIXY XMD - AI Chatbot*\n\n🇹🇿 Imewashwa! Sasa itajibu jumbe za watu moja kwa moja kwa lugha yoyote.\n🇬🇧 Enabled! It will now automatically reply to messages in any language.' 
                }, { quoted: mek });
            } else if (args === 'off') {
                writeChatbotState(false);
                await sock.sendMessage(chatId, { 
                    text: '🤖 *ZENTRIXY XMD - AI Chatbot*\n\n🇹🇿 Imezimwa.\n🇬🇧 Disabled.' 
                }, { quoted: mek });
            } else {
                await sock.sendMessage(chatId, { 
                    text: 'ℹ️ *MATUMIZI / USAGE:*\n\n🇹🇿 • `.chatbot on` - Washa AI auto-reply\n🇹🇿 • `.chatbot off` - Zima AI auto-reply\n\n🇬🇧 • `.chatbot on` - Enable AI auto-reply\n🇬🇧 • `.chatbot off` - Disable AI auto-reply' 
                }, { quoted: mek });
            }
            return;
        }

        // Kama chatbot imezimwa, isifanye chochote
        if (!state.enabled) return;

        // Isijibu jumbe za bot yenyewe
        if (mek.key.fromMe) return;
        if (!body) return;

        // Onyesha inafikiria (typing...)
        await sock.sendPresenceUpdate('composing', chatId);

        // Omba jibu kutoka kwa Gemini AI kwa lugha yoyote ile mtumiaji aliandika
        const aiReply = await getSmartAIResponse(body);

        await sock.sendMessage(chatId, { text: aiReply }, { quoted: mek });

    } catch (error) {
        console.error('Error in Auto Chatbot:', error);
    }
}

// Kuunganisha na Google Gemini API yenye uwezo wa lugha zote
async function getSmartAIResponse(userPrompt) {
    try {
        // Unaweza kuweka API Key yako moja kwa moja hapa kwenye mabano au ikaoma kupitia .env
        const apiKey = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KaCPHN7KiYpGtdjY6uOghpzPljRvprEZGT5TX5G76mWA'; 
        
        if (!apiKey || apiKey === 'AQ.Ab8RN6KaCPHN7KiYpGtdjY6uOghpzPljRvprEZGT5TX5G76mWA') {
            return "⚠️ *Samahani / Sorry:*\n\n🇹🇿 Gemini API Key haijasakinishwa. Tafadhali iweke kwenye faili la .env au kwenye script ya chatbot.js\n\n🇬🇧 Gemini API Key is not installed. Please set it in the .env file or inside chatbot.js";
        }

        const promptInstruction = `Wewe ni msaidizi wa AI mwenye akili nyingi ndani ya WhatsApp bot inayoitwa ZENTRIXY XMD. 
Jibu ujumbe ufuatao kwa lugha ile ile ambayo mtumiaji ametumia kuandikia (iwe Kiswahili, Kiingereza, Kifaransa, Kiarabu, au lugha yoyote ile). Kuwa mchangamfu, msaada, na mstaarabu.

Ujumbe wa mtumiaji: "${userPrompt}"`;

        const response = await axios.post(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
            {
                contents: [{ parts: [{ text: promptInstruction }] }]
            },
            { headers: { 'Content-Type': 'application/json' } }
        );

        const text = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
        return text || "🇹🇿 Samahani, sikuelewa vizuri. Tafadhali rudia tena.\n🇬🇧 Sorry, I didn't understand well. Please repeat.";
    } catch (error) {
        console.error('Gemini API Error:', error.response?.data || error.message);
        return "❌ *Kosa la Mfumo / System Error:*\n\n🇹🇿 Samahani, kosa limetokea wakati wa kuchakata jibu kupitia AI.\n🇬🇧 Sorry, an error occurred while processing the response via AI.";
    }
}

module.exports = { handleAutoChatbot, readChatbotState };
