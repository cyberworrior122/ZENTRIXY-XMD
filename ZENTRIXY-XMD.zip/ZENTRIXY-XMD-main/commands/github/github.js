const moment = require('moment-timezone');
const fetch = require('node-fetch');

async function githubCommand(sock, chatId, message) {
  try {
    // Tumeweka API ya repository yako mpya (cyberworrior122/ZENTRIXY-XMD)
    const res = await fetch('https://api.github.com/repos/cyberworrior122/ZENTRIXY-XMD');
    if (!res.ok) throw new Error('Error fetching repository data');
    const json = await res.json();

    const zipUrl = `https://codeload.github.com/${json.full_name}/zip/refs/heads/${json.default_branch || 'main'}`;

    const caption = [
      `*乂  ZENTRIXY XMD  乂*`,
      '',
      `✩ Repository: ${json.full_name}`,
      `✩ Stars: ${json.stargazers_count}`,
      `✩ Forks: ${json.forks_count}`,
      `✩ Repository URL: ${json.html_url}`,
      `✩ Last Updated: ${moment(json.updated_at).format('DD/MM/YY - HH:mm:ss')}`,
      '',
      '📦 *ZIP File is attached below.*',
      '📦 *Faili la ZIP limeambatanishwa hapa chini.*',
      '',
      '🤖 *Description / Ufafanuzi:*',
      '• *EN:* This is the official repository for ZENTRIXY XMD bot. You can fork, star, or download the source code below.',
      '• *SW:* Hii ni repository rasmi ya bot ya ZENTRIXY XMD. Unaweza kuweka nyota (star), kufanya fork, au kupakua source code hapa chini.'
    ].join('\n');

    await sock.sendMessage(chatId, {
      document: { url: zipUrl },
      fileName: `${json.name}-${json.default_branch || 'main'}.zip`,
      mimetype: 'application/zip',
      caption
    }, { quoted: message });
  } catch (error) {
    await sock.sendMessage(chatId, { text: '❌ Error fetching repository information. / Imeshindikana kupata taarifa za repository.' }, { quoted: message });
  }
}

module.exports = githubCommand;
